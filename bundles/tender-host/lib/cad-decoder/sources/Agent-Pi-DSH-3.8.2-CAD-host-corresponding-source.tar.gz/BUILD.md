# Standalone host DWG decoder

This archive contains the pinned public LibreDWG source, its jsmn submodule,
the bit-cursor patch, the exact build recipe, and linked runtime-library source.
It contains no customer drawings or derived project documents.

Extract into a writable directory. Build the pinned toolchain with:

    docker build -t agent-pi-cad-host-builder -f scripts/cad-clean-builder.Dockerfile .

Run the standalone build with this directory mounted at /workspace:

    docker run --rm --mount type=bind,source=<absolute extracted directory>,target=/workspace agent-pi-cad-host-builder bash scripts/build-cad-host-clean.sh

The JavaScript dependency install uses the upstream frozen pnpm lockfile and
requires registry access unless those locked packages are already cached.
The runtime files, build receipt, and matching source archive appear under
.codex-temp/cad-host-clean-output. Work/output directories must not already
exist; use a fresh extraction for another build.

The build verifies original/patched source hashes, compiles fresh C objects,
runs the upstream Node API tests and 14 regression checks against the actual
compiled C library, then records the resulting runtime and source hashes.
